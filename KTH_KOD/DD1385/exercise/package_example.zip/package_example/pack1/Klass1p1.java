package pack1;

import pack2.*; //eller:  import pack2.Klass1p2;

public class Klass1p1{
    Klass1p2 k1p2;
    
    public static void main(String args[]){
	System.out.println("main in pack1.Klass1");
	Klass2p1 k2p1 = new Klass2p1();
	k2p1.protMetK2p1();

    }

}
