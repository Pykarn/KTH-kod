package pack1;


public class Klass2p1{
    Klass1p1 k1p1 = new Klass1p1();
    
    protected void protMetK2p1(){
	System.out.println("protMetdK2p1 invokes");
    }

    void packageProtMetK2p1(){
	System.out.println("packageProtMetK2p1 invokes");
    }


}
