För att kompilera behöver aktuella mappen vara package_example.
I ett unix-system kan du med hjölp av kommandot "pwd" kolla aktuella mappen:
> pwd
/prutt/package_example
> javac pack1/*.java pack2/*.java
> java pack1.Klass1p1
> java pack2.Klass1p2
