package pack2;

import pack1.Klass2p1;

public class Klass1p2 extends Klass2p1{

    public static void main(String args[]){
	System.out.println("main in pack2.Klass1p2 körs");
	Klass1p2 k1p2 = new Klass1p2();
	k1p2.protMetK1p2();
	//Klass2p1 k2p1 = new Klass2p1();
	k1p2.protMetK2p1();
	
	//	k2p1.protMet(); //<-- kommer inte fungera eftersom att protMet har protected åtkomsmodifierare, lägg märke till att Klass2 är superklass till Klass1p2 spelar ingen roll här
    }

        protected void protMetK1p2(){
	System.out.println("protMetdK1p2 invokes");
    }

}
